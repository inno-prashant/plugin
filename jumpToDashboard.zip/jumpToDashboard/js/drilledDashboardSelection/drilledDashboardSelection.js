//Drilled Dashboard Selection Class

function DrilledDashboardSelection(widget) {
    this.widget = widget;
}