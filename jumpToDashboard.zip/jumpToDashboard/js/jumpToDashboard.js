var allowedTypes = ["pivot", "chart/pie", "chart/line", "chart/area", "chart/bar", "chart/column", "indicator", "chart/scatter", "imageWidget", "richtexteditor", "trelliswidget"];
var otherTypes = ["indicator", "imageWidget", "richtexteditor"];
var proxyUrl = prism.proxyurl ? prism.proxyurl : "";
var sendPieChartMeasureFiltersOnClick = true;

if (typeof main !== 'undefined') {

    main.directive("menuContent", [function () {
        return {
            restrict: 'C',
            link: function ($scope, lmnt, attrs) {
                if ($('.drillable').length > 0 && !$(lmnt).hasClass('drillList')) {

                    $(lmnt).addClass('drillList');
                    lmnt[0].style.opacity = 0; // hide to prevent flickering

                    window.setTimeout(function () {
                        //DOM has finished rendering
                        // now we can detect the frill menu dimensions and move it if necessary
                        var isLeft = $scope.$parent.$parent.isLeftSlideMenu;
                        var container = $(lmnt).closest(".menu-item-host")[0];

                        var isBottom = container.style.bottom;

                        if (isBottom) {
                            var el = $(".menu-item.drillable");
                            var y = el.position().top + container.style.top;
                            container.style.bottom = "";
                            container.style.top = (y - 1) + 'px';
                        }

                        if (isLeft) { // menu will appear to the left
                            //below is a huge hack to make the menu aligned correctly in all supported browsers
                            var dataMenu = $(container).closest("data-menu")[0];
                            container.style.position = "absolute";
                            container.style.left = "-450px";
                            var width = container.offsetWidth;
                            container.style.left = "";
                            container.style.right = "0px"; // align to the right border. this will expand the container to required size.
                            container.style.top = $(dataMenu).find(".drillable").position().top + "px";
                            var drillMenu = $(container).find(".drillList")[0];
                            var drillMenuStyle = getComputedStyle(drillMenu);
                            var borderWidth = (parseInt(drillMenuStyle["border-left-width"]) || 0) + (parseInt(drillMenuStyle["border-right-width"]) || 0);
                            container.style.width = width + borderWidth + "px";
                            container.style.right = dataMenu.offsetWidth + "px";
                        }

                        lmnt[0].style.opacity = 1; // show element back
                    }, 0);
                }
            }
        }
    }]);
}

//hide drilled folders and dashboards by drill prefix for none owners in mobile app
if (appConfig.hideDrilledDashboards && window.sisenseMobileApp && prism.user._id !== $scope.listItem.owner) {

    $('.dashboardListItemWrapper')
        .filter(function (index) {

            var text = $(this).find('.dashboardName').text();

            return text.indexOf(appConfig.drilledDashboardPrefix) === 0

        })
        .hide();
}


//variable for custom config
prism.JTDConfigs = [];

//load widget configuration
prism.jumpToDashboard = function (widget, args) {

    if (args === undefined) {
        return;
    }

    var config = angular.extend(_.clone(appConfig), args);

    //save custom configuration from Edit Script
    prism.JTDConfigs[widget.oid] = config;

    widget.drillToDashboardConfig = config;
    widget.drillToDashboardConfig.custom = true;
};

prism.run([
    'widget-editor.services.$popper',
    'plugin-jumpToDashboard.services.dashboardHideService',
    'ux-controls.services.$browser',
    '$http',
    'plugin-jumpToDashboard.services.dashboardUpdateAttributesService',
    function ($popper, $dashboardHideService, $browser, $http, $dashboardUpdateAttributesService) {

        var originalPopMenuCustom;

        $dashboardHideService.init();

        prism.on("beforemenu", $dashboardHideService.beforeMenuHandler);

        //adds support for Function.name ( IE issue )
        if (Function.prototype.name === undefined && Object.defineProperty !== undefined) {
            Object.defineProperty(Function.prototype, 'name', {
                get: function () {
                    var funcNameRegex = /function\s([^(]{1,})\(/;
                    var results = (funcNameRegex).exec((this).toString());
                    return (results && results.length > 1) ? results[1].trim() : "";
                },
                set: function (value) {
                }
            });
        }

        //removes temporary item from popup
        var removeTempItem = function (items) {
            var tempItem = _.findWhere(items, {caption: 'Temporary_item'});
            if (tempItem) {
                items.splice(items.indexOf(tempItem), 1);
            }

        };

        // Registering widget events
        prism.on("dashboardloaded", function (e, args) {

            // Check if we are on PDF-preview or in phantomJS
            const isPreviewOrPhantom = $('.db-preview-modal').length > 0 || $browser.isPhantomJS();
            
            // Check if the filters should be reset to the state before the JTD
            if (!isPreviewOrPhantom && appConfig.resetDashFiltersAfterJTD && shouldUpdateFilters(args.dashboard)) {
                updateFilters(args.dashboard);
            }

            args.dashboard.on("widgetinitialized", function (dash, args) {
                if (!hasEventHandler(args.widget, "render", onWidgetRender)) {
                    args.widget.on('render', onWidgetRender);
                }

                if (!hasEventHandler(args.widget, "beforeviewloaded", onWidgetRender)) {
                    args.widget.on('beforeviewloaded', onBeforeviewloaded);
                }
            });
            
            args.dashboard.on('filterschanged', function(dash) {
                if (defined(dash.openFromJTD)) {
                    dash.openFromJTD = false;
                    $dashboardUpdateAttributesService.updateAttributes(dash, ['filtersToRestore', 'openFromJTD']);
                }
            });

            //skip, if already overridden
            if (!originalPopMenuCustom) {
                originalPopMenuCustom = $popper.popMenuCustom;

                //override popMenuCustom function
                $popper.popMenuCustom = function (items, ev, ok, ui, settings) {

                    //adds temp fake item to menu drill
                    if (settings && settings.hasOwnProperty('directive') && settings.directive === "<data-menu-drill></data-menu-drill>") {

                        items.push({
                            caption: "Temporary_item",
                            mid: "none"
                        });
                    }
                    originalPopMenuCustom(items, ev, ok, ui, settings);
                    removeTempItem(items);
                }
            }
        });

        function shouldUpdateFilters(dashboard) {
            if (!defined(dashboard.openFromJTD)) {
                return false;
            }

            if (dashboard.openFromJTD) {
                dashboard.openFromJTD = false;
                dashboard.$dashboard.updateDashboard(dashboard, "openFromJTD")
                return dashboard.openFromJTD;
            }

            return true;
        }

        function updateFilters(dashboard) {
            var filtersToRestore = $$get(dashboard, "filtersToRestore");

            // Restore the original filters
            if (filtersToRestore) {
                deleteDashboardAttributes(dashboard, ["filtersToRestore", "openFromJTD"]);

                var options = {
                    refresh: false,
                    save: true, //set false due to ISSUE in dashboard-updated event
                    unionIfSameDimensionAndSameType: true,
                    shouldResetNonSelectedDimensionsFilters: true,
                    reason: 'filtersUpdated'
                };

                dashboard.filters.clear();

                // update dashboard filters according to selected drill item
                dashboard.filters.update(filtersToRestore, options);
            }
        }

        function deleteDashboardAttributes(dashboard, attributes) {
            attributes.forEach(function (att) {
                dashboard[att] = null;
            });

            // Update attributes directly. Was needed to send attributes with null value to mongoDB
            $dashboardUpdateAttributesService.updateAttributes(dashboard, attributes);
        }


        //add drilling image indicator
        function setDrillingImage(widget, args) {
            var widgetElement = getWidgetElement(widget),
                drillImageElement = widgetElement.find('.drillImg');

            if (!drillImageElement.length && args.widget.drillToDashboardConfig.showJTDIcon) {
                widgetElement.find('widget-dragger').after("<div class='drillImg' title='This widget is jumpable' />");
            }

            //target dashboard is set through widget menu or target dashboard ids is set through widget script
            if (args.widget.options.drillTarget || args.widget.drillToDashboardConfig.dashboardIds.length) {
                widgetElement.addClass('jumpable');

            } else {
                widgetElement.removeClass('jumpable');
            }
        }

        function getWidgetJTDConfig(widget) {
            var config = _.clone(appConfig);

            // Adds custom configuration to widget
            if (prism.JTDConfigs[widget.oid]) {
                config = angular.extend(config, prism.JTDConfigs[widget.oid]);
            }

            // Set custom navigation type for pivot widget
            if (widget.type === 'pivot' && config.drillToDashboardNavigateTypePivot) {
                config.drillToDashboardNavigateType = config.drillToDashboardNavigateTypePivot;
            }
            // Pie charts without categories gets a left click JTD automatically
            else if(isPieChartWithoutCategories(widget)){
                config.drillToDashboardNavigateType = 3;
            }
            // Set custom navigation type for chart widgets
            else if (widget.type.match('^chart') && config.drillToDashboardNavigateTypeCharts) {
                config.drillToDashboardNavigateType = config.drillToDashboardNavigateTypeCharts;
            }
            // Set custom navigation type for other Type widgets
            else if (otherTypes.indexOf(widget.type) !== -1
                && config.drillToDashboardNavigateTypeOthers) {
                config.drillToDashboardNavigateType = config.drillToDashboardNavigateTypeOthers;
            }

            if (!defined(config.sendPieChartMeasureFiltersOnClick)) {
                config.sendPieChartMeasureFiltersOnClick = true;
            }

            return config;
        }

        function onBeforeviewloaded(widget, args) {
            var isPieChartWithNoCategories = isPieChartWithoutCategories(widget);

            var config = setWidgetConfig(widget);

            // Check if widget type is supported and widget has JTD enabled
            if (!defined(widget.options.drillTarget) &&
                    widget.drillToDashboardConfig.dashboardIds.length === 0) {
                return;
            }

            // Apply right click on line chart
            if ($$get(config, "drillToDashboardNavigateType") === 3 &&
                widget.type === "chart/line") {
                args.options.plotOptions.series.point.events.click = function (target) {
                    // Pass the target to the getFilters function if you wish to pass the widget filters
                    // to the JTD
                    var xAxisItems = widget.metadata.items(function(item) {
                        return item.$$panel.name === "x-axis" && !item.disabled;
                    });

                    var filters = getFilters(widget, target) || [];
                    var selectionData = target.point.selectionData;

                    if ($$get(xAxisItems, "length") > 0 && selectionData) {
                        _.each(xAxisItems, function (item, index) {
                            var existingFilter = _.find(filters, function (existsFilter) {
                                return existsFilter.jaql.dim === item.jaql.dim;
                            });

                            var newFilter = existingFilter || { jaql: item.jaql };

                            if (!existingFilter) {
                                filters.push(newFilter);
                            }

                            newFilter.jaql.filter = {
                                explicit: true,
                                members: [selectionData[index]],
                                multiSelection: true
                            };
                        });
                    }

                    widget.drilledDashboardDisplay.display(filters,
                        widget.drillToDashboardConfig,
                        widget.options.drillTarget);
                };
            }

            // Apply click on pie chart
            if (isPieChartWithNoCategories) {
                args.options.plotOptions.pie.point.events.click = function (target) {
                    // Pass the target to the getFilters function if you wish to pass the widget
                    // filters to the JTD
                    var targetToSend = config.sendPieChartMeasureFiltersOnClick ? target : undefined;
                    var filters = getFilters(widget, targetToSend);
                    widget.drilledDashboardDisplay.display(filters,
                        widget.drillToDashboardConfig,
                        widget.options.drillTarget);
                };
            }
        }

        function setWidgetConfig(widget) {
            var config = getWidgetJTDConfig(widget);
            widget.drillToDashboardConfig = config;
            return config;
        }

        function onWidgetRender(widget, args) {
            // Check if widget type is supported
            if (allowedTypes.indexOf(args.widget.type) === -1) {
                return;
            }

            var config = setWidgetConfig(args.widget);

            if (!config.dashboardId) {
                new DrilledDashboardSelectionMenu(args.widget);
            } else {
                delete args.widget.options.drillTarget;
                new DrilledDashboardSelectionId(args.widget);
            }

            setDrillingImage(widget, args);

            if (!args.widget.options.drillTarget && !config.dashboardIds.length) {
                return;
            }

            switch (config.drillToDashboardNavigateType) {
                case 2:
                    new DrillToDashboardNavigateTypeLink(args.widget);
                    break;
                case 3:
                    new DrillToDashboardNavigateTypeClick(args.widget);
                    break;
                default:
                    new DrillToDashboardNavigateTypeRightClick(args.widget).initialize();

            }
        }
    }
]);

// utility function to check if model contains certain event handler for specified event name
var hasEventHandler = function (model, eventName, handler) {
    return model.$$eventHandlers(eventName).indexOf(handler) >= 0;
};

var getDashboardFiltersToRestore = function (dashboardOID) {
    // todo: check for v5.8
    //** SUPPORT FOR API 0.9 & 1.0 **//
    var api = '',
        apiType = 'GET',
        params = "",
        filters;

    //if API version > 5
    if (prism.version.split('.')[0] > 5) {
        api = 'v1/';
        // send the datasource due to a bug
        params = "?fields=filters%2Cdatasource%2CfiltersToRestore"
    }

    //open drilled dashboard modal window
    $.ajax({
        "url": proxyUrl + "/api/" + api + "dashboards/" + dashboardOID + params,
        "type": apiType,
        async: false
    })
        .done(function (data) {
            filters = data.filtersToRestore || data.filters;
        });

    return filters;
};

var popNotFoundModal = function () {
    var $dom = prism.$injector.get("ux-controls.services.$dom");

    $dom.modal({
        scope: "fake",
        template: "<jtd-error-msg></jtd-error-msg>",
        css: "err-modal"
    });
};


function getWidgetElement(widget) {

    var widgetElement;
    switch (prism.$ngscope.appstate) {
        case "widget":
            widgetElement = $(".widget-body").not(".prism-persistent-mainview-holder .widget-body");
            break;
        case "dashboard":
            widgetElement = $('widget[widgetid="' + widget.oid + '"]').not("[widget-preview='true']");
            break;
        default:
            widgetElement = $('widget[widgetid="' + widget.oid + '"]').not("[widget-preview='true']");
    }
    return widgetElement
}





