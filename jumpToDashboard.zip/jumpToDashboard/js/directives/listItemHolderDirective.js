// Modify 'listItemHolder' directive to hide shared dashboards and folders by drilled prefix and by active 'hide for non-owners' configuration.
// Hides dashboards for non-owners in dashboards navigator left panel.

navver.directive('listItemHolder', [
    'plugin-jumpToDashboard.services.dashboardHideService',
    function (dashboardHideService) {
        return {
            restrict: 'C',
            link: function link($scope, lmnt, attrs) {

                var listItem = $scope.listItem;

                if (prism.user._id !== listItem.owner) {

                    appConfig.hideDrilledDashboards && dashboardHideService.hidePrefixedListItem(listItem, lmnt);

                    if (appConfig.hideSharedDashboardsForNonOwner) {
                        dashboardHideService.getDashboardsHideModel()
                            .then(function (dashboardsHideModel) {

                                var isHidden = false;

                                if (listItem.objType === 'dashboard') {
                                    isHidden = $$get(_.find(dashboardsHideModel, _.matcher({oid: listItem.oid})), dashboardHideService.hideFlagAttr);
                                }
                                else if (listItem.objType === 'folder') {
                                    isHidden = dashboardHideService.getNavverItemDashboards(listItem)
                                        .every(function (dashboard) {
                                            var dashboardHideFlag = $$get(_.find(dashboardsHideModel, _.matcher({oid: dashboard.oid})), dashboardHideService.hideFlagAttr);
                                            var isDashboardShared = dashboard.owner !== prism.user._id;

                                            return isDashboardShared && dashboardHideFlag;
                                    });
                                }

                                if (isHidden) {
                                    (lmnt).hide();
                                }

                            });
                    }
                }
            }
        }
    }
]);