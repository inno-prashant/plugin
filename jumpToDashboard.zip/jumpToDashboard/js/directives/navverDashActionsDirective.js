// Modify 'navverDashActions' directive to show additional 'hide for non-owners' action button in 'multi select' dashboards navigator mode.

navver.directive('navverDashActions', [
    'plugin-jumpToDashboard.services.dashboardHideService',
    'navver.factories.navverFactory',
    '$compile',
    function (dashboardHideService, navverFactory, $compile) {
        return {
            restrict: 'C',
            link: function link($scope, lmnt, attrs) {

                if (appConfig.hideSharedDashboardsForNonOwner) {

                    var dashboardsHideButton = angular.element('<navver-hide-action></navver-hide-action>');

                    lmnt.find('.navver-dash-actions-buttons').append(dashboardsHideButton);
                    $compile(dashboardsHideButton)($scope);

                    $scope.description = dashboardHideService.hideForViewerStrings.descriptionMultiSelect;

                    $scope.clickHandler = function(event) {
                        dashboardHideService.popHideForViewerConfirmation(event, getSelectedOwnDashboards());
                    };

                    $scope.isDisabled = function() {
                        return !getSelectedOwnDashboards().length;
                    };

                    function getSelectedOwnDashboards() {
                        return navverFactory.getAllSelectedDashboards().filter(function(dash) {
                            return !dash.shared;
                        });
                    }

                }
            }
        }
    }
]);