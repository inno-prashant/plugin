// Modify 'homeTilesList' directive to hide shared dashboards by drilled prefix and by active 'hide for non-owners' configuration
// Hides dashboards for non-owners in the homepage tiles list section

if (window.home) {

    home.directive('homeTilesList', [
        'plugin-jumpToDashboard.services.dashboardHideService',
        function (dashboardHideService) {
            return {
                restrict: 'C',
                link: function link($scope, lmnt, attrs) {

                    $scope.$watchCollection('items', function (items) {

                        if (!items) {
                            items = [];
                        }

                        var allowedItems = items;

                        if (appConfig.hideDrilledDashboards) {
                            // Hide dashboards for non owners + if dash has prefix + if dash in folder that has prefix
                            allowedItems = allowedItems.filter(function (item) {
                                var isDashOwner = prism.user._id === item.owner,
                                    isHiddenByDashPrefix = dashboardHideService.hasPrefix(item.title, appConfig.drilledDashboardPrefix),
                                    isHiddenByFolderPrefix = dashboardHideService.isDashInPrefixedFolder(item, appConfig.drilledDashboardsFolderPrefix);
                                return isDashOwner || !isHiddenByDashPrefix && !isHiddenByFolderPrefix;
                            });

                            if (allowedItems.length !== items.length) {
                                $scope.items = allowedItems;
                            }
                        }

                        if (appConfig.hideSharedDashboardsForNonOwner) {
                            dashboardHideService.getDashboardsHideModel()
                                .then(function (dashboards) {
                                    allowedItems = allowedItems.filter(function (item) {
                                        var dashboard = _.find(dashboards, _.matcher({oid: item.oid}));
                                        return !$$get(dashboard, dashboardHideService.hideFlagAttr) || prism.user._id === item.owner;
                                    });

                                    if (allowedItems.length !== $$get($scope.items, 'length')) {
                                        $scope.items = allowedItems;
                                    }
                                });
                        }

                    });
                }
            }
        }
    ]);
}