// Drilled Dashboard Display Modal class

function DrilledDashboardDisplayModal(){
    DrilledDashboardDisplay.call(this);
}

DrilledDashboardDisplayModal.prototype = Object.create(DrilledDashboardDisplay.prototype);
DrilledDashboardDisplayModal.prototype.constructor = DrilledDashboardDisplayModal;



//display the drilled dashboard in modal window
DrilledDashboardDisplayModal.prototype.display = function(filters, drillToDashboardConfig, drilledDashboard){
    DrilledDashboardDisplay.prototype.display.call(this, filters, drillToDashboardConfig, drilledDashboard);

    //set modal window width
    if (!defined(drillToDashboardConfig.modalWindowWidth)) {
        var width = Math.max(Math.floor($(window).outerWidth() * 5 / 6), 500);
    }
    else{
        var width = drillToDashboardConfig.modalWindowWidth
    }

    //set modal window height
    if (!defined(drillToDashboardConfig.modalWindowHeight)) {
        var height = Math.max(Math.floor($(window).outerHeight() * 5 / 6), 400);
    }
    else{
        var height = drillToDashboardConfig.modalWindowHeight;
    }

    // create the modal template
    var iframeDiv ='<iframe class="drill-popup"  src="'+ this.url +'" width="' + width + 'px" height="' + height + 'px" ></iframe>';

    // get the dom service
    var $dom = prism.$injector.get("ux-controls.services.$dom");

    // create the settings
    var settings = {template : iframeDiv, scope:'fake', css: "resize-modal" }; // Hack for $dom service

    //** SUPPORT FOR API 0.9 & 1.0 **//
    var api = '';
    var apiType = 'PUT';
    var body = document.getElementsByTagName("body")[0];
    var startX;
    var startY;
    var startWidth;
    var startHeight;
    var minModalWidth = 40;
    var minModalHeight = 40;
    var draggedModal; //current modal being resized

    //if API version > 5
    if(prism.version.split('.')[0]>5){
       api = 'v1/';
       apiType = 'PATCH';
    }

    //open drilled dashboard modal window after updating target dashboard filters
    $.ajax({
        "url"       : proxyUrl + "/api/" + api + "dashboards/" + drilledDashboard.oid,
        "type"      : apiType,
        "data"      : this.payload,
        contentType : "application/json;charset=UTF-8",
        success:function() {

            // create modal
            $dom.modal(settings);

            if (drillToDashboardConfig.modalWindowResize) {
                allowModalResize();
            }

            // HACK: sets event listener for overlay div, and fires the $dom click event
            var overlay = $('div.md-overlay');
            overlay.bind('click', function () {
                $('body').trigger('click');
                overlay.unbind('click', arguments.callee);
            });
        },
        error: function(err){
            if (err.status === 404){
                popNotFoundModal();
            } else {
                throw err;
            }
        }
    });

    function allowModalResize() {
        var resizer = $("<div class='resizer'></div>");
        $(".md-modal").append(resizer);
        resizer.on('mousedown', initDrag);
    }

    //initialize drag
    function initDrag(e) {
        draggedModal = $(e.target).parent();
        startX = e.clientX;
        startY = e.clientY;
        startWidth = parseInt(getComputedStyle(draggedModal[0]).width, 10);
        startHeight = parseInt(getComputedStyle(draggedModal[0]).height, 10);
        var body = $("body");
        body.on('mousemove', doDrag);
        body.on('mouseup', stopDrag);
        draggedModal.find(".md-content").css("overflow", "hidden");
        draggedModal.find(".md-content").prepend("<div class='drill-overlay'></div>");
    }

    //execute dragging
    function doDrag(e) {
        var width = Math.max(startWidth + 2 * (e.clientX - startX), minModalWidth);
        var height = Math.max(startHeight + 2 * (e.clientY - startY), minModalHeight);

        draggedModal.width(width + 'px');
        draggedModal.height(height + 'px');
    }

    //stop dragging
    function stopDrag(e) {
        var body = $("body");
        var drillPopUp = $('.drill-popup');
        body.off('mousemove', null, doDrag);
        body.off('mouseup', null, stopDrag);
        drillPopUp.width((startWidth + 2 * (e.clientX - startX) - 27 ) + 'px');
        drillPopUp.height((startHeight + 2 * (e.clientY - startY) - 27) + 'px');
        draggedModal.find(".md-content").css("overflow","");
        $(".drill-overlay").remove();
    }
};