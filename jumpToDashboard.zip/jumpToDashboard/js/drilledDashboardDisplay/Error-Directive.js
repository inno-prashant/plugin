mod.directive('jtdErrorMsg', [
    function () {
        return {
            templateUrl: "/plugins/jumpToDashboard/styles/404.html",
            restrict: 'E',
        };
    }
]);

