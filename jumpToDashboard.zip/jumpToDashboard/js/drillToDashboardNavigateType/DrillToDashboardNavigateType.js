// Drill To Dashboard Navigate Type Class

function DrillToDashboardNavigateType(widget) {
    //check if widget type supported
    if (this.allowedTypes.indexOf(widget.type) === -1) {
        return;
    }

    //set drilled dashboard display mode
    switch(widget.drillToDashboardConfig.drilledDashboardDisplayType) {
        case 1:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayNewTab();
            break;
        case 2:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayModal();
            break;
        case 3:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayCurrentTab();
            break;
        default:
            widget.drilledDashboardDisplay = new DrilledDashboardDisplayNewTab();
            break;
    }
}

DrillToDashboardNavigateType.prototype.allowedTypes = [];

//create drill to dashboard navigation
DrillToDashboardNavigateType.prototype.create = function(){};

// get all filters, remove filters disabled on widget-level
function getFilters(widget, target) {

    // get widget filters object
    var widgetFilterObject = getWidgetFilters(widget, target);

    // assign widget filters object key/values to variables
    var widgetFilters = widgetFilterObject.allFilters,
        widgetFilterDims = widgetFilters.map(function(f) {
            return f.jaql.dim;
        }),
        disabledDashboardFilters = widgetFilterObject.disabled,
        disableAllDashboardFilters = widgetFilterObject.ignoreAll; // boolean

    // set dashboard filter and merged filter defaults
    var dashboardFilters = widget.dashboard.filters.getEnabledItems(),
        filters;

    if (disableAllDashboardFilters) {
        filters = getDashboardOrWidgetFilters(widgetFilters);
    } else {
        filters = getDashboardOrWidgetFilters(widgetFilters).concat(getDashboardOrWidgetFilters(dashboardFilters));
    }

    if (disabledDashboardFilters.length > 0) {
        // remove filters explicitly disabled on the widget-level:
        //  return array of filters with dims included in widgetFilterDims or not found in disabledDashboardFilters
        filters = _.filter(filters, function(f) {
            if (f.isCascading) {
                return _.any(f.levels, function (level) {
                    return _.contains(widgetFilterDims, level.dim) ? true : !_.contains(disabledDashboardFilters, level.dim);
                });
            } else {
                return _.contains(widgetFilterDims, f.jaql.dim) ? true : !_.contains(disabledDashboardFilters, f.jaql.dim);
            }
        });
    }

    return getFiltersWithoutDuplicates(filters);
}

function isPieChartWithoutCategories(widget){
    if (widget.type !== 'chart/pie'){
        return false;
    }

    return !widget.metadata.panel('categories').getEnabledItems().length;
}

// get widget filters together with measured filters (those which are set up in formula)
function getWidgetFilters(widget, target){
    var measuredFilters = [];
    var widgetFilters = widget.metadata.filters();
    var valuesPanel = widget.metadata.panel("values");
    var valuePanel = widget.metadata.panel("value");
    var seriesName = isPieChartWithoutCategories(widget) ? $$get(target, "point.name")
        : $$get(target, "point.series.name");
    var breakByPanel = widget.metadata.panel("break by");

   // var isPieChartWithNoCategories = isPieChartWithoutCategories(widget);

    if (valuesPanel && seriesName){
        var panelItem;

        if ($$get(breakByPanel, "items.length")) {
            // find active dim from "values" panel when "break by" exist
            panelItem = _.find(valuesPanel.items, function(item) {
                return !item.disabled;
            });
        }
        else {
            panelItem = _.find(valuesPanel.items, function(item){
                var title = $$get(item, "jaql.title");
                return title && title === seriesName;
            });
        }

        if (panelItem){
            measuredFilters = getMeasuredValueFilters(panelItem);
        }
    }

    // collect measured value filters from "indicator" widget
    if (valuePanel) {
        measuredFilters = getMeasuredValueFilters(valuePanel.items[0]);
    }

    // need to return both here -> disabled are removed after dash filter merge
    return {
        allFilters: measuredFilters.concat(widgetFilters),
        ignoreAll: widget.metadata.ignore.all,
        disabled: widget.metadata.ignore.dimensions
    };
}

function getDashboardOrWidgetFilters(dashboardOrWidgetFilters){
    var filters = [];
    dashboardOrWidgetFilters.forEach(function (f) {

        var filterObj;

        if (f.isCascading) {

            filterObj = {levels: $.extend(true, [], f.levels), model:$.extend(true, {}, f.model), isCascading: true}

        } else {

            filterObj = {
                jaql:  $.extend(true, {}, f.jaql)
            }

        }

        if (f.locked === true) {
            filterObj.locked = true;
        }

        filters.push(filterObj);
    });

    return filters;
}

// iterate through filters and remove those containing duplicate dimensions or add the filter into the cascading filter levels which contain duplicate dimension
function getFiltersWithoutDuplicates(filters){
    if(!filters.length){
        return filters;
    }
    var result = [],
        indexesToRemove = [];

    filters.forEach(function(filterItem, idx){
        result.push(filterItem);

        if(!filterItem.isCascading && filterItem.jaql.dim){
            var dim = filterItem.jaql.dim.toLowerCase();
            var remainingFilters = filters.slice(idx + 1);
            if(!remainingFilters.length) return;

            var duplicates = findDuplicateFilters(dim, remainingFilters);

            if(duplicates.length){
                if (isLockedFilterInFilters(duplicates)) {
                    result[result.length - 1].locked || (result[result.length - 1].locked = true);
                }

                duplicates.forEach(function(f){
                    if(f.isCascading){
                        replaceCascFilterItem(f, filterItem); // if filter exists in the cascaded filter, we want to put the value and not adding standalone filter item.
                        indexesToRemove.unshift(filters.indexOf(filterItem)); // saving the indexes of the unnecessary filters to remove later.
                    }else{

                        var index = filters.indexOf(f);
                        if (index < 0) {
                            return;
                        }
                        filters.splice(index, 1);

                    }
                })
            }
        }
    });

    // a loop to remove unnecessary filter items.
    while (indexesToRemove.length !== 0){
        result.splice(indexesToRemove[0],1);
        indexesToRemove.shift();
    }
    
    return result;
}

function isLockedFilterInFilters(filters) {
    return ~_.findIndex(filters, function (item) {
        return item.locked
    });
}

function replaceCascFilterItem(cascFilter, filterItem){
    var matchedItem = _.find(cascFilter.levels, function(lvl){
       return lvl.dim === filterItem.jaql.dim;
    });

    matchedItem.filter = filterItem.jaql.filter;
}

function removeFilter(by) {

    var index = -1;
    var findStr = by;

    if (_.isObject(by)){
        findStr = by.isCascading ? by.getDimensions()[0] : by.jaql.dim;
    }

    // dimensionality input
    if (_.isString(by) || _.isObject(by)) {

        for (var i = 0; i < this.$$items.length; i++) {

            var currItem = this.$$items[i];

            if ((defined(currItem.hasDimension) && currItem.hasDimension(findStr)) ||
                (!defined(currItem.hasDimension) && currItem.jaql.dim == findStr)) {

                index = i;
                break;
            }
        }
    }

    // index input
    else if (_.isNumber(by)) {

        index = by;
    }

    // verifying index
    if (index < 0 || index > this.$$items.length) {

        throw 'index out of range';
    }
    var modifiedItem = this.$$items[index];

    var unUnionPerformed = (options.unUnionIfSameDimensionAndSameType) ? modifiedItem.unmergeWith(by)  /*this.tryUnUnion(this.$$items[i], by) */: false;

    if (!unUnionPerformed) {
        this.$$items.splice(index, 1);
    } else {

        // When unselecting in a cascading filter, need to start a refresh cycle.
        if(defined(modifiedItem.refresh) && modifiedItem.isCascading)
            modifiedItem.refresh(by.jaql || by);

        this.$$handleEmptyMembersFilterIfNecessary(modifiedItem);
    }

};

// remove cascading filter levels for specific dimension
function removeLevels (filter, dim){
    var levels = filter.levels;
    for (var i = levels.length - 1; i >= 0; i--) {
        if(levels[i].dim.toLowerCase() === dim){
            levels.splice(i, 1);
        }
    }
}

// find filters by dimension
function findDuplicateFilters(dim, filters){
    return filters.filter(function(item){
        if(item.isCascading) { // for cascading filter find those which contain levels for specific dimension
            var filters = item.levels.filter(function (item) {
                return item.dim.toLowerCase() === dim;
            });
            return !!filters.length;
        }

        return !item.isCascading && item.jaql.dim && item.jaql.dim.toLowerCase() === dim;
    });
}

//merge filters excluding those with duplicate dimensions
function mergeFilters(firstFilters, secondFilters){
    return getFiltersWithoutDuplicates($.merge(firstFilters, secondFilters));
}

//get cell filters
function getCellFilters(widget, cell){
    //create filter object
    function createFilter(items, fieldIndex, value){
        var item = {jaql:{}};
        var tmpitem = $.grep(items,function(i){return i.field.index == fieldIndex && !i.disabled})[0];

        item.jaql.datatype = tmpitem.jaql.datatype;
        item.jaql.dim = tmpitem.jaql.dim;
        item.jaql.filter = value ? {members : [value]} : {all:true};
        item.jaql.title = tmpitem.jaql.title;

        if (tmpitem.jaql.level) {
            item.jaql.level = tmpitem.jaql.level;
        }

        return item;
    }

    function isLowermostMeasureHeader(classString){
        return (classString.indexOf("p-measure-head") >=0 ||
            classString.indexOf("p-total-head") >= 0 &&
            classString.indexOf("p-dim-member") < 0 ||
            classString.indexOf("p-grand-total-head") >= 0);
    }

    function isLowermostHeaderClass(classString){
        return (classString.indexOf("p-dim-head") >= 0 || isLowermostMeasureHeader(classString));
    }

    function getLowermostHeaderCellsInOrder(table){
        function scanSubtree(rowIndex){
            for(;leavesToFindInCurrentSubtree[rowIndex] > 0;)
                scanSubtree(rowIndex + rowSpansOfCurrentSubtree[rowIndex]);

            var indexOfCellWithinRow = cellIndices[rowIndex];
            var currentRow = headerRows[rowIndex];

            if(currentRow && !(currentRow.cells.length <= indexOfCellWithinRow)){
                var numberOfLeavesInSubtree = parseInt(currentRow.cells[indexOfCellWithinRow].getAttribute("colspan") || 1);
                var rowSpan = parseInt(currentRow.cells[indexOfCellWithinRow].getAttribute("rowspan") || 1);

                if((numberOfLeavesInSubtree > 1 || !isLowermostHeaderClass(currentRow.cells[indexOfCellWithinRow].className)) && headerRows.length >= rowIndex + rowSpan + 1)
                    return leavesToFindInCurrentSubtree[rowIndex] = numberOfLeavesInSubtree || 1, cellIndices[rowIndex]++, rowSpansOfCurrentSubtree[rowIndex] = rowSpan, void scanSubtree(rowIndex+rowSpan);

                elements.push(currentRow.cells[indexOfCellWithinRow]), cellIndices[rowIndex]++;

                for(var i=0;rowIndex>i;++i)leavesToFindInCurrentSubtree[i]--;scanSubtree(0)}
        }

        for(var elements=[],headerRows=$(table).find("thead tr:not(.p-fake-measure-head)"),cellIndices=[],leavesToFindInCurrentSubtree=[],rowSpansOfCurrentSubtree=[],i=0;i<headerRows.length;++i)
            cellIndices.push(0),leavesToFindInCurrentSubtree.push(0),rowSpansOfCurrentSubtree.push(0);

        return scanSubtree(0),elements
    }

    // given a cell, gets the dimension member row cells for that cell, for all row dimensions. (i.e, for a value cell of row 'tel aviv -> israel -> asia', returns the cells for 'tel aviv', 'israel', 'asia')
    // cell can be either a value cell, or a dimension member cell
    function getRowCells(cell, dimensionsContainer) {

        // version 7 fix for pivot jump via right click menu
        if (parseInt(prism.version.charAt(0)) >= 7) {

            $cellNodeName = $(cell).prop('nodeName');

            if ($(cell).is('.wrapper') ||
                $(cell).is('.p-value') && $cellNodeName === 'DIV' ) {
                cell = cell.parentNode;
            }

            if ($(cell).is('.p-head-content')) {
                cell = cell.parentNode.parentNode;
            }

            if ($cellNodeName === 'SPAN') {
                cell = cell.parentNode.parentNode.parentNode;
            }

            dimensionsContainer.context = cell;
        }

        var dimCellId = $(cell.parentNode.cells).filter('.p-dim-member:last, .p-total-row-head:last, .p-grand-total-row-head:last').prop('id'); //last dimension is guaranteed to be in the same row as value
        var currCell = cell.className.indexOf('p-dim-member') >= 0 ? cell : dimensionsContainer.find('td[originalid = "' + dimCellId + '"], td#' + dimCellId)[0];	// get corresponding cell in the dimensions container
        var allDimensionMemberCells = $(currCell).parents('tbody').find('td.p-dim-member');
        var rowCells = [];
        var lastFoundCell = currCell;
        var currCellIndex = currCell ? parseInt(currCell.getAttribute('fIdx')) : -1;

        if (currCellIndex === -1){
            return [];
        }
        if (currCellIndex === 0 || $(currCell).hasClass("p-grand-total-row-head")) {
            return [currCell];
        }

        while (currCellIndex > 0) {
            var currRow = lastFoundCell.parentNode;

            while (!currCell) {
                currRow = node_before(currRow);

                if (!currRow){
                    currCellIndex -= 1;
                    break;
                }

                currCell = $(currRow).find('td.p-dim-member[fIdx = ' + (currCellIndex - 1) + ']')[0];
            }

            while (currCell) {
                currCellIndex = parseInt(currCell.getAttribute('fIdx'));
                rowCells = $.merge(rowCells, [currCell]);
                lastFoundCell = currCell;
                currCell = node_before(currCell);
            }
        }

        return rowCells;
    }

    function node_before(sib){
        while(sib = sib.previousElementSibling) {
            if (!is_ignorable(sib)) {
                return sib;
            }
        }
        return null;
    }

    function is_ignorable(nod){
        return nod.nodeType === 8 || nod.nodeType === 3 && is_all_ws(nod) || nod.className.indexOf("p-fake-measure-head") !== -1;
    }

    function is_all_ws(nod){
        return !/[^\t\n\r ]/.test(nod.data || nod.innerText);
    }

    function getCellsByIndexAndValue(allCells,fieldIndex,value,isDateTime){
        function exactTextMatch(){
            return isDateTime?_.isEqual(Date.parseDate(this.getAttribute("val")),value):this.getAttribute("val") === value;
        }

        var matchingCells = allCells.filter(exactTextMatch).filter("[fIdx = "+fieldIndex+"], [fDimensionIdx = "+fieldIndex+"]");

        return matchingCells;
    }

    function getCellsFromSameFieldWithSameTextValue(allCells,cell){
        var value = $(cell).attr("val"),fieldIndex=parseInt(cell.getAttribute("fIdx"));

        return getCellsByIndexAndValue(allCells,fieldIndex,value);
    }

    // given a cell, gets the dimension member column header cells for that cell, for all column dimensions. (i.e for a value cell of column 'ipod nano -> apple' returns 'ipod nano', 'apple'
    // cell can be either a value cell, or a dimension member header cell.
    function getColumnCells(cell, headersContainer, orderedLowermostCells, isLowermostHeaderCell) {
        var columnCells = [];
        var headerCell = cell;
        if (!isLowermostHeaderCell) {
            var indexAmongstValueCells = $(cell).parent().children('td.p-value').index(cell);
            headerCell = _.reject(orderedLowermostCells, function(c){
                return c.className.indexOf('p-dim-head') >= 0;
            })[indexAmongstValueCells];
        }

        if (!headerCell){
            return columnCells;
        }

        // find appropriate header cells. the lowermost row has the same columns as the values row; therefore- the cell index would be the same.
        var allDimensionHeaderCells = $(headersContainer).find('td.p-dim-member-head');

        if (headerCell.className.indexOf('p-dim-member-head') < 0) {
            // not a dimension member (a value header)- retrieve the correct dimension header using the measure path, if available
            headerCell = allDimensionHeaderCells.filter('[measurePath = \'' + headerCell.getAttribute('measurePath') + '\']')[0] || headerCell;
        }

        var allCellsWithSameValue = getCellsFromSameFieldWithSameTextValue(allDimensionHeaderCells, headerCell);
        $.merge(columnCells, allCellsWithSameValue);

        var measurePath = headerCell.getAttribute('measurePath');
        if (!measurePath)
            return columnCells;

        var lastIndexOfComma = measurePath.lastIndexOf('","');
        while (lastIndexOfComma > 0) {
            measurePath = measurePath.slice(0, lastIndexOfComma + 1) + '}';
            headerCell = headersContainer.find('thead td[measurePath = \'' + measurePath + '\']')[0];

            var allCellsWithSameValue = getCellsFromSameFieldWithSameTextValue(allDimensionHeaderCells, headerCell);
            $.merge(columnCells, allCellsWithSameValue);

            lastIndexOfComma = measurePath.lastIndexOf('","');
        }
        return columnCells;
    }

    if (cell.tagName !== "TD"){
        cell = $(cell).closest('td')[0];
    }

    var lowermostCells = getLowermostHeaderCellsInOrder($(cell).parents('table'));
    var colCells = getColumnCells(cell, $(cell).parents('table'), lowermostCells);
    var rowCells = getRowCells(cell, $(cell).parents('table'));

    if(cell.className.indexOf('p-first-data-col') > -1){
        var rowsCount = _.filter(widget.metadata.panel("rows").items, function (item){
            return !item.disabled
        }).length;
        var columnsCount = _.filter(widget.metadata.panel("columns").items, function (item){
            return !item.disabled
        }).length;

        var itemsIndex = rowsCount + columnsCount;
    }
    else{
        var itemsIndex = parseFloat(cell.getAttribute('fidx'));
    }

    var filters = [];
    var measuredValue = _.find(widget.metadata.panel('values').items, function(item){
        return item.field.index == itemsIndex && !item.disabled
    });
    var measuredValueFilters = getMeasuredValueFilters(measuredValue);

    $.merge(rowCells, colCells);
    var isGrandTotalRow;

    angular.forEach(rowCells, function (memberCell) {
        var fieldIndex;
        var items;
        isGrandTotalRow = false;

        if (memberCell.className.indexOf('p-measure-head') >= 0){
            fieldIndex = parseInt(memberCell.getAttribute('fDimensionIdx'));
            items = widget.metadata.panel('columns').items;
        }
        else if (memberCell.className.indexOf('p-dim-member-head') == 0){
            fieldIndex = parseInt(memberCell.getAttribute('fIdx'));
            items = widget.metadata.panel('columns').items;
        }
        else if(memberCell.className.indexOf('p-grand-total-row-head') > -1){
            fieldIndex = 0;
            isGrandTotalRow = true;
            items = widget.metadata.panel('rows').items;
        }
        else {
            fieldIndex = parseInt(memberCell.getAttribute('fIdx'));
            items = widget.metadata.panel('rows').items;
        }

        /*
        Do not use these methods:
            $(memberCell)[0].innerText - adds \n to the end of the string [PSE-378]
            $(memberCell).attr('val')  - encodes the special symbols [PSE-276]
            $(memberCell).text() - skips datetime values
         */

        var textval = $("<span>").html($(memberCell).attr('val')).text();    //decodes and keeps datetime
        var filter = createFilter(items, fieldIndex, textval);

        if(isGrandTotalRow){  // for grand total row we don't want to always add 'include all' filter for row dimension
            var widgetFilters = widget.metadata.filters();
            var filtersWithoutDuplicates = getFiltersWithoutDuplicates(widgetFilters.concat(filter));
            if(filtersWithoutDuplicates.length <= widgetFilters.length){ // widget filter with such dimension already exists

                // don't move this filter to new dashboard because current widget
                // has a widget filter with more precise criterion which needs to be preserved.
                return;
            }
        }

        filters.push(filter);
    });

    return filters.concat(measuredValueFilters);
}
// get measured value filters (those which are set up in formula)
function getMeasuredValueFilters(measuredValue){
    var context = $$get(measuredValue, "jaql.context");
    var formula = $$get(measuredValue, "jaql.formula");

    // Breaks and return empty filters list if formula or context not exist
    if (!formula || !context) return [];

    var contextProps = parseFormulaForContexts(formula);

    // Collect filters of each context from formula
    var filters = contextProps.reduce(function(acc, prop) {

        var jaql = context[prop];

        if (jaql.filter) {
            acc.push({jaql: jaql});
        }

        return acc;
    }, []);

    // Remove redundant filters for same dimension
    return _.uniq(filters, false, function(item) {
        return item.jaql.dim;
    });
}

// get contexts from formula
function parseFormulaForContexts(formula) {
    var pattern = /\[(.*?)\]/g;
    return _.uniq(formula.match(pattern));
}
