function DrillToDashboardNavigateTypeRightClick(widget) {
    if (widget.options.drillTarget || widget.drillToDashboardConfig.dashboardIds.length) {
        this.allowedTypes = ["chart/pie", "chart/line", "chart/area", "chart/bar", "chart/column", "indicator", "pivot", "chart/scatter", "imageWidget", "richtexteditor", "trelliswidget"];

        this.initialize = function () {
            DrillToDashboardNavigateType.call(this, widget);

            var menuFactory = new RightClickMenuFactory();
            var rightClickMenuCreationFunction = menuFactory.getMenuCreationFunction(widget);
            var beforeMenuEventHandlers = $$get(prism.$ngscope.$$listeners["beforemenu"]);

            //check if event already registered
            if (beforeMenuEventHandlers && beforeMenuEventHandlers.filter(function (e) {
                    return (e && e.name == rightClickMenuCreationFunction.name);
                }).length > 0) {
                return;
            }

            //unregister events
            function removeOnBeforeMenu(widget) {
                beforeMenuHandler();
                widget.off("destroyed", removeOnBeforeMenu);
            }

            //set events
            var beforeMenuHandler = prism.on("beforemenu", function (ev, args) {

                if ($$get(args,"settings.name") === "widgetindashboard"){
                    var exportToImgOrig;
                    var wHeader = $(args.ui.target[0]);
                    var exportToImage = _.find(args.settings.items, function(item){
                        return item.caption === "Download";
                    });

                    if (exportToImage){
                        exportToImgOrig = exportToImage.items[0].command.execute;
                    }else{
                        return;
                    }


                    exportToImage.items[0].command.execute = newExecute;
                    function newExecute(){
                        $(".transput-caption",wHeader).css("text-overflow","clip");
                        exportToImgOrig();
                        setTimeout(function(){
                            $(".transput-caption",wHeader).css("text-overflow","ellipsis");
                        }, 10000);
                    }
                }

                if (!args.settings.widget)
                    return;

                var func = menuFactory.getMenuCreationFunction(args.settings.widget);
                if (func.name !== "createCustomMenuItem") {
                    func(ev, args);
                }
            });

            widget.on("destroyed", removeOnBeforeMenu);
        };
   }
}

DrillToDashboardNavigateTypeRightClick.prototype = Object.create(DrillToDashboardNavigateType.prototype);
DrillToDashboardNavigateTypeRightClick.prototype.constructor = DrillToDashboardNavigateTypeRightClick;
