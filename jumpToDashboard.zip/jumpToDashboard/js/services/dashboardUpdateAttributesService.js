mod.service("dashboardUpdateAttributesService", [
    '$http',
    function ($http) {
        this.updateAttributes = function(dashboard, attributes){
            var data = _.pick(dashboard, attributes);
            var dashboardsUrl = '/api/dashboards/';
            var dashboardid = dashboard.oid;

            var putUrl = dashboardsUrl + dashboardid;

            return $http({
                method: 'PUT',
                url: putUrl,
                data: data,
                cache: false,
            }).then(function (resp) {
                return resp;
            });
        };
    }]);