#Drill to dashboard supports charts, pivots and indicators

For pivots supports: dashboard filters, widget filters, measured values.
For charts support: dashboard filters, widget filters.

#Steps to implement:
1. Extract the folder to prismweb/plugins
2. Create a dashboard with prefix _drill_ or folder with  prefix _drill_
3. Go to the source dashboard and in the widget you want to drill from go to its edit window and in the menu you will have drill to dashboard options which you can choose to which
dashboard to jump to, select a target dashboard
4. Click apply
5. Right click on a point/cell and choose "drill to dashboard"


#Changing default settings:

- Edit widget script: prism.jumpToDashboard(widget, args)

- Set args to the parameter you'd like to update:
    1.  Set drilledDashboardPrefix to empty string - will cause all dashboards to be potential drilled dashboards:
        prism.jumpToDashboard(widget, { drilledDashboardPrefix  : ""});
    2. Exclude brand dimension from the drilled dashboard filters:
        prism.jumpToDashboard(widget, { excludeFilterDims  : "[brand.Brand]"});

- Set multiple target dashboards (NOTE: not applicable to pivot link navigation type):
     Add widget script like the following:
     prism.jumpToDashboard(widget, {
                                        dashboardIds  : [
                                                            {id:"568a8d9eaca677c414000001", caption:"Dashboard Name"},
                                                            {id:"123a8d9f3fd678c433000003", caption:"Other New Name"}
                                                        ]
                                   }
                           );


#Changing the "drilledDashboardsFolderPrefix" parameter:

By default it equals to empty string.
- If you change this parameter to "_xyz" and NOT clear the "drilledDashboardPrefix" parameter then
  The dashboards from the folder  that matches "_xyz" AND all the dashboard that are prefixed with "_drill_" will be potential drilled dashboards.
- If you change this parameter to "_xyz" and clear the "drilledDashboardPrefix" parameter then
  Only the dashboards from the folder which name matches "_xyz" will be potential drilled dashboards.
- When this parameter is empty it's not taken into consideration


#Settings:

Key                                 Description                                                                         Type                        DefaultValue
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
drilledDashboardPrefix              The prefix of the drilled dashboards name or folder.                                string                      "_drill_"
drilledDashboardsFolderPrefix       The prefix of the folder, the dashboards inside which can be drilled to.            string                      ""
displayFilterPane                   Display filter pane in the drilled dashboard window.                                boolean                     true
displayDashboardsPane               Display dashboards pane in the drilled dashboard window.                            boolean                     true
displayToolbarRow                   Display toolbar in the drilled dashboard window.                                    boolean                     true
displayHeaderRow                    Display header in the drilled dashboard window.                                     boolean                     true
volatile                            Volatile for the drilled dashboard window.                                          boolean                     true
hideDrilledDashboards               Hide drilled dashboards from the dashboards navigator for non owner users.          boolean                     true
hideSharedDashboardsForNonOwner     Adds a context menu item that allows to hide shared dashboard from the dashboards   boolean                     true
                                    navigator for non owner users.
drillToDashboardMenuCaption         The caption for the drill to dashboard menu                                         string                      "Jump to dashboard"
drillToDashboardRightMenuCaption    The caption for the drill to dashboard right menu                                   string                      "Jump to dashboard"
drillToDashboardNavigateType        How to navigate to the configured drilled dashboard                                 NavigateTypeId (See Bellow) 1
drillToDashboardNavigateTypePivot   Custom navigation type for pivot widget                                             NavigateTypeId (See Bellow) 1
drillToDashboardNavigateTypeCharts  Custom navigation type for chart widgets                                            NavigateTypeId (See Bellow) 1
drillToDashboardNavigateTypeOthers  Custom navigation type for other widgets (indicator, richtexteditor, imageWidget)   NavigateTypeId (See Bellow) 1
excludeFilterDims                   Dimensions to exclude from the drilled dashboard filter                             Array of DIM (See Bellow)   []
includeFilterDims                   Dimensions to include in the drilled dashboard filter                               Array of DIM (See Bellow)   []
drilledDashboardDisplayType         How to display the drilled dashboard                                                DisplayTypeId (See Bellow)    1
dashboardId                         Drilled dashboard id.
                                    When set to null, a drilled dashboard menu will be avilable in the widget editor,   string                      null
                                    allowing the user to choose the drilled dashboard from the menu.
dashboardIds                        Multiple target Dashboards                                                          Array of objects            []
                                                                                                                        {id:"", caption:""}
dashboardCaption                    Drilled dashboard caption.                                                          string                      null
modalWindowWidth                    Modal window width, In case the selected display type is modal window.              number                      null
modalWindowHeight                   Modal window height, In case the selected display type is modal window.             number                      null
modalWindowResize                   Enable resize for modal window, In case the selected display type is modal window.  boolean                     false
sameCubeRestriction                 Use same ecube for the drilled dashboards                                           boolean                     true
showFolderNameOnMenuSelection       In case true, the folder name will be shown before the dashboard title inside the
                                    dashboards list menu                                                                boolean                     false
resetDashFiltersAfterJTD            Should reset filters of a dashboard that was opened from Jump to Dashboard          boolean                     false
showJTDIcon                         Rather to show an icon for widgets that has JTD in the widget title                 boolean                     true
sendPieChartMeasureFiltersOnClick   Apply measure filters on pie chart if the drill type is set to click                boolean
forceZeroInsteadNull                In Pivot show Zero-values instead of null                                           boolean                     false

DIM:
string represent dimension: "[table.dimension]".
Example: "[brand.Brand]"

Navigate Type:

Id  Description                                     Supported Widget Types
------------------------------------------------------------------------------
1   Right click on a pivot cell/ point or indicator Pivot, Indicator, Charts ,Rich Text Editor, Image Widget
2   Link on pivot measured cells                    Pivot
3   Click on custom widget                          Indicator ,Rich Text Editor, Image Widget, pie chart


Display Type:

Id  Description
-----------------
1   New tab
2   Popup window
3   Current tab

# Enabled "hideSharedDashboardsForNonOwner" parameter will allow hiding functionality of shared dashboards from the navigator panel and dashboard tiles on home page for non owner users:
- Adds "Hide" checkbox option to dashboard menu and navigator panel items (dashboards and folders).
- Adds "Hide for non-owner" action button to navigator panel in multi-select mode.
- User can hide only own dashboards.
- Shows confirmation message after "Hide" checkbox/button click.
- Dashboard will be automatically re-published after its "Hide" configuration changes.

Hide selected shared dashboards from the dashboards navigator for non owner users


# Notes:
- Pie charts with no categories - Pie charts that do not contain categories, are jumpable via left click.
The pie is recognized automatically as a non categories chart, regardless the config settings,
and left click is applied instead of right click.

# Limitations:
- In case you want to apply locked filters to jumpable dashboard, refresh the page after locking filters on parent dashboard.
(Only for admins, and dashboard owners)